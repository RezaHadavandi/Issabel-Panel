#!/usr/bin/env bash
# نصب با یک خط:  curl -fsSL https://raw.githubusercontent.com/YOUR_USER/issabel-panel/main/install.sh | sudo AMI_PASS='xxx' bash
set -euo pipefail
REPO="${PANEL_REPO:-https://github.com/YOUR_USER/issabel-panel.git}"
DIR="${PANEL_DIR:-/opt/issabel-panel}"
[ "$(id -u)" = 0 ] || { echo "با sudo اجرا کنید"; exit 1; }
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
if [ -f ./docker-compose.yml ]; then DIR="$(pwd)"; else
  command -v git >/dev/null || { apt-get update && apt-get install -y git || yum install -y git; }
  if [ -d "$DIR/.git" ]; then git -C "$DIR" pull --ff-only; else git clone --depth 1 "$REPO" "$DIR"; fi
fi
cd "$DIR"
if [ ! -f .env ]; then
  cp .env.example .env; chmod 600 .env
  sed -i "s|^APP_SECRET=.*|APP_SECRET=$(openssl rand -hex 32)|;s|^HOOK_SECRET=.*|HOOK_SECRET=$(openssl rand -hex 24)|" .env
  [ -n "${AMI_USER:-}" ] && sed -i "s|^AMI_USER=.*|AMI_USER=$AMI_USER|" .env
  [ -n "${AMI_PASS:-}" ] && sed -i "s|^AMI_PASS=.*|AMI_PASS=$AMI_PASS|" .env
fi
DC="docker compose"; $DC version >/dev/null 2>&1 || DC="docker-compose"
$DC up -d --build
sleep 5; echo "-------- اطلاعات ورود مدیر (فقط بار اول) --------"
$DC logs panel 2>&1 | grep 'ADMIN LOGIN' || echo "قبلاً ساخته شده؛ لاگ: $DC logs panel"
echo "آدرس: http://<IP-سرور>:3000   |  HOOK_SECRET برای دایال‌پلن در $DIR/.env"
