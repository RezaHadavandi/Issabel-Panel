'use strict';
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dur=s=>{s=+s||0;return[s/3600|0,s%3600/60|0,s%60].map(n=>String(n).padStart(2,'0')).join(':')};
const toast=t=>{const m=$('#msg');m.textContent=t;m.className='show';clearTimeout(toast.t);toast.t=setTimeout(()=>m.className='',3000)};
const NAV={admin:['dash','ext','calls','q','rep','cdr','team','srv'],supervisor:['dash','ext','calls','q','rep','team'],operator:['q','rep'],observer:['rep','cdr']};
const T={dash:'داشبورد',ext:'داخلی‌ها',calls:'تماس‌های زنده',q:'صف‌ها',rep:'گزارش‌ها',cdr:'تاریخچه',team:'کاربران و واحدها',srv:'مدیریت سرور'};
const ROLE={admin:'مدیر',supervisor:'سرپرست',operator:'اپراتور',observer:'ناظر'};
const LIVE=new Set(['dash','ext','calls','q']),mext=l=>((l||'').match(/\/(\d+)/)||[])[1];
let ME,ST,cur;
document.documentElement.dataset.theme=localStorage.theme||'';
async function api(p,b,m){const meth=m||(b?'POST':'GET'),body=meth!=='GET';const r=await fetch('/api/'+p,{method:meth,credentials:'same-origin',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(b||{}):undefined});
  let j={};try{j=await r.json()}catch{}if(r.status===401&&p!=='login'){login();throw new Error('نشست منقضی شد')}if(!r.ok)throw new Error(j.error||r.status);return j}
const stars=a=>a==null?'<span class="mute">—</span>':`<span class="stars" title="${a}">${'★'.repeat(Math.round(a))}${'☆'.repeat(5-Math.round(a))}</span> ${a}`;
const tbl=(h,rows,e='موردی نیست')=>rows.length?`<table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${rows.join('')}</table>`:`<p class="mute">${e}</p>`;
const dt=t=>new Date(t).toLocaleString('fa-IR');
function login(msg){cur=null;$('#app').innerHTML=`<form class="login card" id="lf"><h2>ورود به پنل ایزابل</h2><input name="u" autocomplete="username" placeholder="نام کاربری" required><input name="p" type="password" autocomplete="current-password" placeholder="رمز عبور" required><button>ورود</button><small class="bad">${esc(msg||'')}</small></form>`;
  $('#lf').onsubmit=async e=>{e.preventDefault();try{await api('login',{username:e.target.u.value,password:e.target.p.value});boot()}catch(x){login(x.message)}}}
async function boot(){try{ME=await api('me')}catch{return login()}
  $('#app').innerHTML=`<aside><div class="brand">پنل ایزابل <small class="mute">v${esc(ME.version)}</small></div><nav>${NAV[ME.role].map(k=>`<button data-v="${k}">${T[k]}</button>`).join('')}</nav><div class="me"><span>${esc(ME.name||ME.username)}<small> ${ROLE[ME.role]}</small></span><button class="g" data-a="theme">تم</button><button class="g" data-a="pw">رمز</button><button class="g" data-a="out">خروج</button></div></aside><main><div id="err" class="bad"></div><div id="view"></div></main>`;go(NAV[ME.role][0])}
async function go(v){cur=v;document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
  try{if(LIVE.has(v))await tick(true);else $('#view').innerHTML=await V[v]()}catch(e){$('#view').innerHTML=`<p class="bad">${esc(e.message)}</p>`}}
async function tick(force){if(!LIVE.has(cur))return;const a=document.activeElement;if(!force&&a&&/INPUT|SELECT/.test(a.tagName)&&a.closest('#view'))return;
  try{ST=await api(cur==='me'?'mycall':'state');$('#err').textContent=ST.error?'اتصال AMI: '+ST.error:'';$('#view').innerHTML=V[cur](ST)}catch(e){$('#err').textContent=e.message}}
setInterval(()=>tick(),2500);
const can=ME=>ME.role==='admin'||ME.role==='supervisor';
const calls=s=>tbl(['مبدأ','مقصد','وضعیت','مدت','کانال',''],s.channels.map(c=>`<tr><td>${esc(c.CallerIDNum)} ${esc(c.CallerIDName)}</td><td>${esc(c.ConnectedLineNum||c.Exten)}</td><td>${esc(c.ChannelStateDesc)}</td><td>${dur(c.Duration)}</td><td>${esc(c.Channel)}</td><td>${can(ME)?`<button class="d" data-a="hangup" data-ch="${esc(c.Channel)}">قطع</button>`:''}</td></tr>`),'تماس فعالی وجود ندارد.');
const V={
 dash:s=>{const on=s.peers.filter(p=>p.online).length,w=s.queues.reduce((n,q)=>n+q.callers.length,0);
  return`<div class="stats">${[[s.peers.length,'داخلی'],[on,'آنلاین'],[s.peers.filter(p=>p.busy).length,'مشغول'],[s.channels.length,'کانال فعال'],[s.queues.length,'صف'],[w,'در انتظار']].map(([n,l])=>`<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('')}</div>
  <div class="card"><h2>تماس سریع</h2><div class="row"><input id="from" inputmode="numeric" placeholder="از داخلی"><input id="to" inputmode="tel" placeholder="به شماره"><button data-a="call">برقراری تماس</button></div></div><div class="card"><h2>تماس‌های زنده</h2>${calls(s)}</div>`},
 ext:s=>`<div class="card">${tbl(['داخلی','وضعیت','آدرس'],s.peers.map(p=>`<tr><td>${esc(p.name)}</td><td><span class="tag ${p.busy?'warn':p.online?'ok':'bad'}">${p.busy?'مشغول':p.online?'آنلاین':'آفلاین'}</span></td><td>${esc(p.ip)}</td></tr>`),'داخلی‌ای پیدا نشد.')}</div>`,
 calls:s=>`<div class="card">${calls(s)}</div>`,
 q:s=>{if(ME.role==='operator'){if(!ME.ext)return'<p class="warn">داخلی برای حساب شما ثبت نشده؛ با سرپرست تماس بگیرید.</p>';
   return s.queues.map(Q=>{const m=Q.members.find(m=>mext(m.Location)===ME.ext);return`<div class="card q"><div><b>${esc(Q.Queue)}</b><small>${esc(Q.Calls)} در انتظار</small></div>${m?`<button class="g" data-a="qpause" data-q="${esc(Q.Queue)}" data-p="${m.Paused==='1'?0:1}">${m.Paused==='1'?'ادامه کار':'استراحت'}</button>`:''}
    <label class="sw" aria-label="عضویت در صف ${esc(Q.Queue)}"><input type="checkbox" role="switch" data-q="${esc(Q.Queue)}" ${m?'checked':''}><span></span></label></div>`}).join('')||'<p class="mute">صفی تعریف نشده.</p>'}
  return s.queues.map(Q=>`<div class="card"><h2>صف ${esc(Q.Queue)} <small class="mute">| انتظار ${esc(Q.Calls)} · پاسخ ${esc(Q.Completed)} · از دست رفته ${esc(Q.Abandoned)}</small></h2>
   <div class="row"><input data-in="${esc(Q.Queue)}" inputmode="numeric" placeholder="داخلی"><button data-a="qadd" data-q="${esc(Q.Queue)}">افزودن عضو</button></div>
   ${tbl(['عضو','تماس‌ها','وضعیت',''],Q.members.map(m=>`<tr><td>${esc(m.Name||m.Location)}</td><td>${esc(m.CallsTaken)}</td><td>${m.Paused==='1'?'<span class="tag warn">استراحت</span>':'<span class="tag ok">فعال</span>'}</td>
    <td><button class="g" data-a="qpause" data-q="${esc(Q.Queue)}" data-e="${esc(mext(m.Location))}" data-p="${m.Paused==='1'?0:1}">${m.Paused==='1'?'ادامه':'استراحت'}</button> <button class="d" data-a="qrem" data-q="${esc(Q.Queue)}" data-e="${esc(mext(m.Location))}">حذف</button></td></tr>`),'عضوی نیست')}
   ${Q.callers.length?`<p class="mute">در انتظار: ${Q.callers.map(c=>esc(c.CallerIDNum)+' ('+dur(c.Wait)+')').join('، ')}</p>`:''}</div>`).join('')||'<p class="mute">صفی تعریف نشده.</p>'},
 rep:async()=>{const f=$('#f')?.value||new Date(Date.now()-30*864e5).toISOString().slice(0,10),t=$('#t')?.value||new Date().toISOString().slice(0,10),r=await api(`report?from=${f}&to=${t}`);
  return`<div class="row"><input type="date" id="f" value="${f}"><input type="date" id="t" value="${t}"><button data-a="rep">نمایش</button></div>
  <div class="card"><h2>امتیاز رضایت مشتریان به تفکیک اپراتور</h2>${tbl(['اپراتور','داخلی','تعداد تماس','نظرسنجی‌شده','میانگین امتیاز','مدت مکالمه'],r.agents.map(a=>`<tr><td>${esc(a.name||'—')}</td><td>${esc(a.ext)}</td><td>${a.calls}</td><td>${a.rated}</td><td>${stars(a.avg)}</td><td>${dur(a.talk)}</td></tr>`),'در این بازه تماسی ثبت نشده.')}</div>
  <div class="card"><h2>آخرین تماس‌ها</h2>${tbl(['زمان','مشتری','اپراتور','مدت','امتیاز','پیامک'],r.recent.map(c=>`<tr><td>${dt(c.ts)}</td><td dir="ltr">${esc(c.caller)}</td><td>${esc(c.agent)}</td><td>${dur(c.dur)}</td><td>${stars(c.score)}</td><td>${c.sms==='sent'?'<span class="ok">ارسال شد</span>':c.sms==='fail'?'<span class="bad">ناموفق</span>':'—'}</td></tr>`))}</div>`},
 cdr:async()=>{const d=$('#day')?.value||new Date().toISOString().slice(0,10);let h='';try{const r=await api('cdr?date='+d);h=tbl(['زمان','مبدأ','مقصد','مدت','وضعیت'],r.map(x=>`<tr><td>${esc(x.calldate)}</td><td>${esc(x.src)}</td><td>${esc(x.dst)}</td><td>${dur(x.billsec)}</td><td>${esc(x.disposition)}</td></tr>`),'تماسی ثبت نشده.')}catch(e){h=`<p class="warn">${esc(e.message)}</p>`}
  return`<div class="row"><input type="date" id="day" value="${d}"><button data-a="cdrgo">نمایش</button></div><div class="card">${h}</div>`},
 team:async()=>{const[us,un]=await Promise.all([api('users'),api('units')]),adm=ME.role==='admin',sups=us.filter(u=>u.role==='supervisor');
  return`<div class="card"><h2>واحدها</h2><div class="row"><input id="un" placeholder="نام واحد">${adm?`<select id="us"><option value="">بدون سرپرست</option>${sups.map(s=>`<option value="${s.id}">${esc(s.name||s.username)}</option>`).join('')}</select>`:''}<button data-a="mkunit">ایجاد واحد</button></div>${tbl(['واحد','اعضا'],un.map(u=>`<tr><td>${esc(u.name)}</td><td>${u.n}</td></tr>`),'واحدی نیست')}</div>
  <div class="card"><h2>افزودن کاربر</h2><div class="row"><input id="nu" placeholder="نام کاربری" autocomplete="off"><input id="nn" placeholder="نام نمایشی"><input id="np" type="password" placeholder="رمز (حداقل ۱۰ کاراکتر)" autocomplete="new-password"><input id="ne" inputmode="numeric" placeholder="داخلی">
   ${adm?`<select id="nr">${Object.entries(ROLE).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select>`:''}<select id="nunit"><option value="">بدون واحد</option>${un.map(u=>`<option value="${u.id}">${esc(u.name)}</option>`).join('')}</select><button data-a="mkuser">ایجاد</button></div></div>
  <div class="card"><h2>کاربران</h2>${tbl(['نام کاربری','نام','نقش','داخلی','واحد','وضعیت',''],us.map(u=>`<tr><td>${esc(u.username)}</td><td>${esc(u.name)}</td><td>${ROLE[u.role]}</td><td>${esc(u.ext)}</td><td>${u.role==='operator'?`<select data-uid="${u.id}"><option value="">—</option>${un.map(x=>`<option value="${x.id}" ${x.id===u.unit_id?'selected':''}>${esc(x.name)}</option>`).join('')}</select>`:''}</td><td>${u.active?'<span class="ok">فعال</span>':'<span class="bad">غیرفعال</span>'}</td>
   <td><button class="g" data-a="uact" data-id="${u.id}" data-v="${u.active?0:1}">${u.active?'غیرفعال':'فعال'}</button> <button class="g" data-a="upw" data-id="${u.id}">رمز جدید</button></td></tr>`))}</div>`},
 srv:async()=>{const s=await api('settings'),c=s.sms;
  return`<div class="card"><h2>اتصال به آسترسک (AMI)</h2><p>${esc(s.ami.host)} — ${s.ami.connected?'<span class="ok">متصل</span>':`<span class="bad">قطع: ${esc(s.ami.error||'')}</span>`}</p></div>
  <div class="card"><h2>پنل پیامک</h2><p class="mute">در URL و بدنه از {to} {text} {from} استفاده کنید. کلید API را در هدرها (JSON) بدهید؛ رمزنگاری‌شده ذخیره می‌شود.</p>
  <div class="row"><label><input type="checkbox" id="se" ${c.enabled?'checked':''}> ارسال خودکار پیامک بعد از تماس</label></div>
  <div class="row"><input id="su" dir="ltr" size="46" placeholder="https://api.example.com/send" value="${esc(c.url)}"><select id="sm"><option ${c.method==='POST'?'selected':''}>POST</option><option ${c.method==='GET'?'selected':''}>GET</option></select><select id="st"><option value="json" ${c.type==='json'?'selected':''}>JSON</option><option value="form" ${c.type==='form'?'selected':''}>Form</option></select></div>
  <textarea id="sh" dir="ltr" placeholder='${c.has_hdr?'هدرها ذخیره شده؛ برای تغییر JSON جدید بدهید':'{"Authorization":"Bearer KEY"}'}'></textarea>
  <textarea id="sb" dir="ltr" placeholder='{"to":"{to}","from":"{from}","text":"{text}"}'>${esc(c.body)}</textarea>
  <div class="row"><input id="sl" dir="ltr" size="30" placeholder="خطوط پیامکی، با کاما جدا کنید" value="${esc(c.lines.join(','))}"><select id="sd">${c.lines.map(l=>`<option ${l===c.line?'selected':''}>${esc(l)}</option>`).join('')}</select></div>
  <textarea id="sx" placeholder="متن پیامک">${esc(c.text)}</textarea>
  <div class="row"><button data-a="sms">ذخیره</button><input id="stn" dir="ltr" placeholder="09xxxxxxxxx"><button class="g" data-a="smst">ارسال تست</button></div></div>`}};
document.addEventListener('change',async e=>{const i=e.target;if(i.matches('.sw input')){try{await api('queue/'+(i.checked?'add':'remove'),{queue:i.dataset.q,ext:ME.ext});toast(i.checked?'وارد صف شدید':'از صف خارج شدید')}catch(x){toast(x.message);i.checked=!i.checked}tick(true)}});
document.addEventListener('click',async e=>{const t=e.target.closest('[data-v],[data-a]');if(!t)return;const d=t.dataset,v=id=>$('#'+id).value.trim();
  if(d.v&&!d.a)return go(d.v);
  try{switch(d.a){
   case'out':await api('logout',{});return login();
   case'theme':{const n=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=localStorage.theme=n;return}
   case'pw':{const o=prompt('رمز فعلی');if(!o)return;const n=prompt('رمز جدید (حداقل ۱۰ کاراکتر)');if(!n)return;await api('password',{old:o,pw:n});toast('رمز تغییر کرد');return}
   case'call':await api('originate',{from:v('from'),to:v('to')});toast('تماس ارسال شد');break;
   case'hangup':if(!confirm('تماس قطع شود؟'))return;await api('hangup',{channel:d.ch});toast('قطع شد');break;
   case'qadd':await api('queue/add',{queue:d.q,ext:document.querySelector(`[data-in="${CSS.escape(d.q)}"]`).value.trim()});toast('اضافه شد');break;
   case'qrem':if(!confirm('از صف حذف شود؟'))return;await api('queue/remove',{queue:d.q,ext:d.e});toast('حذف شد');break;
   case'qpause':await api('queue/pause',{queue:d.q,ext:d.e||ME.ext,paused:d.p==='1'});toast('انجام شد');break;
   case'rep':case'cdrgo':return go(d.a==='rep'?'rep':'cdr');
   case'mkunit':await api('units',{name:v('un'),supervisor_id:$('#us')?.value});toast('واحد ساخته شد');return go('team');
   case'mkuser':await api('users',{username:v('nu'),name:v('nn'),password:$('#np').value,ext:v('ne'),role:$('#nr')?.value,unit_id:$('#nunit').value});toast('کاربر ساخته شد');return go('team');
   case'uact':await api('users/'+d.id,{active:d.v==='1'},'PATCH');return go('team');
   case'upw':{const n=prompt('رمز جدید (حداقل ۱۰ کاراکتر)');if(!n)return;await api('users/'+d.id,{password:n},'PATCH');toast('رمز تغییر کرد');return}
   case'sms':await api('settings/sms',{enabled:$('#se').checked,url:v('su'),method:$('#sm').value,type:$('#st').value,headers:v('sh'),body:$('#sb').value,lines:v('sl').split(',').map(x=>x.trim()).filter(Boolean),line:$('#sd').value,text:$('#sx').value},'PUT');toast('ذخیره شد');return go('srv');
   case'smst':await api('settings/sms/test',{to:v('stn')});toast('پیامک تست ارسال شد');return}
   if(LIVE.has(cur))tick(true)}catch(x){toast('خطا: '+x.message)}});

// ===== نسخه 2.1 =====
Object.assign(NAV,{admin:['dash','ext','calls','q','rep','cdr','book','team','phones','voice','srv'],supervisor:['dash','ext','calls','me','q','book','rep','team'],operator:['me','q','book','rep'],observer:['rep','cdr']});
Object.assign(T,{me:'تماس من',book:'دفترتلفن',phones:'تلفن‌ها',voice:'صداها'});LIVE.add('me');
const person=c=>!c?'<p class="mute">اتصال CRM فعال نیست.</p>':c.error?`<p class="warn">${esc(c.error)}</p>`:c.none?'<p class="mute">این شماره در CRM یافت نشد.</p>':`<table><tr><th>نام</th><td>${esc(c.name)}</td><th>شرکت</th><td>${esc(c.company)}</td></tr><tr><th>سمت</th><td>${esc(c.job)}</td><th>ایمیل</th><td dir="ltr">${esc(c.email)}</td></tr><tr><th>موبایل</th><td dir="ltr">${esc(c.mobile)}</td><th>تلفن</th><td dir="ltr">${esc(c.phone)}</td></tr></table>${c.more?`<small class="mute">${c.more} مشتری دیگر هم با این شماره هست</small>`:''}`;
const hist=h=>tbl(['زمان','اپراتور','صف','مدت','امتیاز'],(h||[]).map(x=>`<tr><td>${dt(x.ts)}</td><td>${esc(x.an||x.agent)}</td><td>${esc(x.queue)}</td><td>${dur(x.dur)}</td><td>${stars(x.score)}</td></tr>`),'سابقه‌ای ثبت نشده');
V.me=s=>!ME.ext?'<p class="warn">داخلی برای حساب شما ثبت نشده.</p>':!s.active?'<div class="card"><h2>تماس فعلی</h2><p class="mute">تماسی در جریان نیست. با رسیدن تماس، اطلاعات مشتری و سابقه‌اش اینجا نمایش داده می‌شود.</p></div>':`<div class="card"><h2>${esc(s.state)} — <span dir="ltr">${esc(s.caller||'شماره نامشخص')}</span> · ${dur(s.dur)}</h2>${person(s.crm)}</div><div class="card"><h2>سابقه‌ی تماس این شماره</h2>${hist(s.history)}</div>`;
V.book=async()=>{const q=$('#bq')?.value.trim()||'';let h='';if(q)try{if(/^[+\d\s-]{5,}$/.test(q)){const r=await api('lookup?number='+encodeURIComponent(q));h=`<div class="card">${person(r.crm)}</div><div class="card"><h2>سابقه‌ی تماس</h2>${hist(r.history)}</div>`}
  else{const r=await api('crm/search?q='+encodeURIComponent(q));h=`<div class="card">${tbl(['نام','شرکت','موبایل','تلفن','ایمیل'],r.map(c=>`<tr><td>${esc(c.name)}</td><td>${esc(c.company)}</td><td dir="ltr">${esc(c.mobile)}</td><td dir="ltr">${esc(c.phone)}</td><td dir="ltr">${esc(c.email)}</td></tr>`),'نتیجه‌ای نیست')}</div>`}}catch(e){h=`<p class="bad">${esc(e.message)}</p>`}
  return`<div class="row"><input id="bq" value="${esc(q)}" placeholder="شماره یا نام مشتری"><button data-a="bk">جستجو در دفترتلفن (CRM)</button></div>`+h};
const _rep=V.rep;V.rep=async()=>{const f=$('#f')?.value||new Date(Date.now()-30*864e5).toISOString().slice(0,10),t=$('#t')?.value||new Date().toISOString().slice(0,10),h=await _rep(),r=await api(`report?from=${f}&to=${t}`),g={};
  r.byQueue.forEach(x=>(g[x.queue||'نامشخص']??=[]).push(x));
  return h+Object.entries(g).map(([q,a])=>{const n=a.reduce((m,x)=>m+x.rated,0),avg=n?(a.reduce((m,x)=>m+x.avg*x.rated,0)/n).toFixed(2):null;
   return`<div class="card"><h2>صف ${esc(q)} — میانگین کل ${stars(avg)} (${n} نظرسنجی)</h2>${tbl(['اپراتور','داخلی','تماس','نظرسنجی','میانگین امتیاز'],a.map(x=>`<tr><td>${esc(x.name||'—')}</td><td>${esc(x.ext)}</td><td>${x.calls}</td><td>${x.rated}</td><td>${stars(x.avg)}</td></tr>`))}</div>`}).join('')};
V.phones=async()=>{const p=await api('phones');return`<div class="card"><h2>افزودن تلفن Grandstream</h2><div class="row"><input id="pn" placeholder="نام"><input id="pi" dir="ltr" placeholder="192.168.1.50"><input id="pu" dir="ltr" value="admin"><input id="pp" type="password" placeholder="رمز تلفن" autocomplete="new-password"><label><input type="checkbox" id="ph" checked> HTTPS</label><button data-a="phadd">افزودن</button></div></div>
 <div class="card">${tbl(['نام','IP','عملیات'],p.map(x=>`<tr><td>${esc(x.name)}</td><td dir="ltr">${esc(x.ip)}</td><td><button class="g" data-a="phinfo" data-id="${x.id}">وضعیت خطوط</button> <button class="g" data-a="phget" data-id="${x.id}">خواندن تنظیمات</button> <button class="g" data-a="phset" data-id="${x.id}">تغییر تنظیمات</button> <button class="d" data-a="phreboot" data-id="${x.id}">ریبوت</button> <button class="d" data-a="phdel" data-id="${x.id}">حذف</button></td></tr>`),'تلفنی ثبت نشده')}<pre id="pout" dir="ltr" style="white-space:pre-wrap"></pre></div>`};
const SL=[['survey-prompt','متن نظرسنجی'],['agent-intro','جمله‌ی «با داخلی … صحبت کردید»'],['thanks','تشکر پایانی'],...[0,1,2,3,4,5,6,7,8,9].map(d=>['digit-'+d,'رقم '+d])];
V.voice=async()=>{const a=await api('audio');return`<div class="card"><p class="mute">برای هر مورد یک فایل WAV تک‌کاناله 16-bit با نرخ 8000 یا 16000 هرتز بارگذاری کنید (ترجیحاً صدای گوینده‌ی خانم فارسی). فایل جدید جایگزین قبلی می‌شود.</p>${tbl(['مورد','بارگذاری','پخش',''],SL.map(([k,l])=>`<tr><td>${l}</td><td><input type="file" accept=".wav,audio/wav" data-up="${k}"></td><td>${a[k]?`<audio controls preload="none" src="/api/audio/${k}/file"></audio>`:'<span class="mute">—</span>'}</td><td>${a[k]?`<button class="d" data-a="audel" data-k="${k}">حذف</button>`:''}</td></tr>`))}</div>`};
const _srv=V.srv;V.srv=async()=>{const h=await _srv(),s=await api('settings'),c=s.crm;
  return h.replace('</p></div>',`${s.ami.ver?' · آسترسک '+esc(s.ami.ver):''}</p></div>`)+`<div class="card"><h2>CRM مایکروسافت Dynamics 365 (فقط‌خواندنی)</h2><p class="mute">پنل فقط درخواست GET می‌فرستد و چیزی در CRM نمی‌نویسد. برای ایمنی بیشتر، Application User را با نقش امنیتی فقط‌خواندنی روی Contact بسازید.</p>
  <div class="row"><label><input type="checkbox" id="ce" ${c.enabled?'checked':''}> فعال</label><input id="co" dir="ltr" size="40" placeholder="https://ORG.crm4.dynamics.com" value="${esc(c.org)}"></div>
  <div class="row"><input id="ct" dir="ltr" size="38" placeholder="Tenant ID" value="${esc(c.tenant)}"><input id="cc" dir="ltr" size="38" placeholder="Client ID" value="${esc(c.client)}"><input id="cs" type="password" autocomplete="new-password" placeholder="${c.has_secret?'Client Secret ذخیره شده':'Client Secret'}"></div>
  <div class="row"><button data-a="crmsave">ذخیره</button><button class="g" data-a="crmtest">آزمایش اتصال</button></div></div>`};
const out=r=>{$('#pout').textContent=JSON.stringify(r,null,1)};
document.addEventListener('click',async e=>{const t=e.target.closest('[data-a]');if(!t)return;const d=t.dataset,v=id=>$('#'+id).value.trim();
  try{switch(d.a){
   case'bk':return go('book');
   case'phadd':await api('phones',{name:v('pn'),ip:v('pi'),user:v('pu'),pw:$('#pp').value,https:$('#ph').checked});toast('ثبت شد');return go('phones');
   case'phdel':if(!confirm('حذف شود؟'))return;await api('phones/'+d.id,{},'DELETE');return go('phones');
   case'phinfo':out(await api(`phones/${d.id}/info`,{}));return;
   case'phget':{const k=prompt('P-valueها با : جدا شوند','P35:P47:P270');if(k)out(await api(`phones/${d.id}/get`,{keys:k}));return}
   case'phset':{const x=prompt('مقدارها، مثال: P47=192.168.1.10&P35=101');if(!x)return;if(confirm('تنظیمات روی تلفن اعمال شود؟'))out(await api(`phones/${d.id}/set`,{values:Object.fromEntries(new URLSearchParams(x))}));return}
   case'phreboot':if(confirm('تلفن ریبوت شود؟'))out(await api(`phones/${d.id}/reboot`,{}));return;
   case'audel':await api('audio/'+d.k,{},'DELETE');return go('voice');
   case'crmsave':await api('settings/crm',{enabled:$('#ce').checked,org:v('co'),tenant:v('ct'),client:v('cc'),secret:$('#cs').value},'PUT');toast('ذخیره شد');return go('srv');
   case'crmtest':await api('settings/crm/test',{});toast('اتصال به Dynamics برقرار است');return}}catch(x){toast('خطا: '+x.message)}});
document.addEventListener('change',async e=>{const i=e.target;
  if(i.matches('select[data-uid]')){try{await api('users/'+i.dataset.uid,{unit_id:i.value},'PATCH');toast('واحد تغییر کرد')}catch(x){toast(x.message)}}
  if(i.matches('input[data-up]')&&i.files[0]){const f=i.files[0],rd=new FileReader();rd.onload=async()=>{try{await api('audio/'+i.dataset.up,{data:String(rd.result).split(',')[1]},'PUT');toast('بارگذاری شد');go('voice')}catch(x){toast(x.message)}};rd.readAsDataURL(f)}});
boot();
