const net=require('net');
function mk(port,old){net.createServer(s=>{s.write('Asterisk Call Manager/'+(old?'1.3':'5.0.1')+'\r\n');let b='';const w=x=>s.write(x+'\r\n\r\n');
 s.on('data',d=>{b+=d;let i;while((i=b.indexOf('\r\n\r\n'))>=0){const m=Object.fromEntries(b.slice(0,i).split('\r\n').map(l=>l.split(': ')));b=b.slice(i+4);const id='ActionID: '+m.ActionID+'\r\n';
  const L=(h,evs,c)=>{w('Response: Success\r\n'+id+(old?'':'EventList: start\r\n')+'Message: list follows');evs.forEach(e=>w(e.replace('\r\n','\r\n'+id)));w(c+'\r\n'+id+(old?'':'EventList: Complete\r\n')+'ListItems: '+evs.length)};
  if(m.Action==='Login'){w('Response: Success\r\n'+id+'Message: ok');setTimeout(()=>{
     w(old?'Event: Join\r\nChannel: SIP/200-1\r\nCallerID: 09124445555\r\nQueue: sales\r\nUniqueid: 77.1':'Event: QueueCallerJoin\r\nChannel: PJSIP/200-1\r\nCallerIDNum: 09124445555\r\nQueue: sales\r\nUniqueid: 77.1');
     setTimeout(()=>w('Event: AgentComplete\r\nQueue: sales\r\nUniqueid: 77.1\r\nMember: Local/105@from-queue/n\r\nTalkTime: 42\r\nReason: caller'),300)},800)}
  else if(m.Action==='CoreSettings')w('Response: Success\r\n'+id+'AsteriskVersion: '+(old?'11.25.1':'18.20.0'));
  else if(m.Action==='CoreShowChannels')L(0,[old?'Event: CoreShowChannel\r\nChannel: SIP/105-1\r\nUniqueID: 9.1\r\nCallerIDnum: 0912\r\nExtension: s\r\nDuration: 00:02:03':'Event: CoreShowChannel\r\nChannel: PJSIP/105-1\r\nUniqueid: 9.1\r\nCallerIDNum: 0912\r\nExten: s\r\nDuration: 00:02:03\r\nChannelStateDesc: Up'],'Event: CoreShowChannelsComplete');
  else if(m.Action==='QueueStatus')L(0,['Event: QueueParams\r\nQueue: sales\r\nCalls: 0','Event: QueueMember\r\nQueue: sales\r\nName: 105\r\nLocation: Local/105@from-queue/n\r\nPaused: 1\r\nStatus: 2'],'Event: QueueStatusComplete');
  else if(m.Action==='SIPpeers')old?L(0,['Event: PeerEntry\r\nObjectName: 105\r\nIPaddress: 10.0.0.5\r\nStatus: OK (4 ms)'],'Event: PeerlistComplete'):w('Response: Error\r\n'+id+'Message: Invalid/unknown command');
  else if(m.Action==='PJSIPShowEndpoints')old?w('Response: Error\r\n'+id+'Message: Invalid/unknown command'):L(0,['Event: EndpointList\r\nObjectName: 105\r\nDeviceState: In use\r\nContacts: 105/sip:105@10.0.0.9'],'Event: EndpointListComplete');
  else w('Response: Error\r\n'+id+'Message: unknown');
 }})}).listen(port,'127.0.0.1')}
mk(15038,true);mk(15039,false);
